
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

     <?php include("validation.php");?>
     <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
      

    <div style="width: 500px; margin-left: 400px; margin-top: 20px; border: 2px solid green; text-align: center;">

<form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>"enctype="multipart/form-data"> 
     

      
         <p>please enter your first name</p>
         <p><input type="text" name="fname" value="<?=$fname?>"></p>
         <span class="error"><?= $fname_error ?></span>
         <p>Please enter your second name</p>
           <p> <input type="text" name="sname" value="<?=$sname?>"> </p>
            <span class="error"><?=$sname_error?></span>
            <p>Please enter your Email adress</p>
            <p><input type="text" name="email" value="<?=$email?>"></p>
            <span class="error"><?=$email_error?></span>
            <p>Please enter your Phone Number</p>
            <p><input type="text" name="phone" value="<?=$phone?>"></p>
            <span class="error"><?=$phone_error?></span>
            <p>Please enter your country of origine</p>
           <p> <input type="text" name="country" value="<?=$country?>"></p>
            <span class="error"><?=$country_error?></span>
            <p>Please Upload your passport picture</p>
         <p><input type="file" name="img1"></p>
           <span class="error"><?=$file_error?></span>
         <p><input type="submit" value="SUBMIT"></p>
         <span class="sucess"><?=$success?></span>
        
        </form>
    </div>


</body>
</html>

  

