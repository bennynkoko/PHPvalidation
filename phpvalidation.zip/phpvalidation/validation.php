<?php

$fname_error = $sname_error = $email_error = $phone_error = $country_error ="";
$fname = $sname = $email = $phone = $country = $file_error = $success = "";

 if($_SERVER["REQUEST_METHOD"]=="POST"){
 	
  if(empty($_POST['fname'])){
  	$fname_error = "First name cannot be empty";
  }
  else{
  	$fname = test_input($_POST["fname"]);
    if (!ctype_alpha($fname) ){ $fname_error= "only letters are allow";}
  }

  if (empty($_POST["sname"])){
  	$sname_error = "this field cannot be empty";
  }else{
  	$sname = test_input($_POST["sname"]);
  	if(!ctype_alpha($sname)){
  		$sname_error = "Only letters and white spaces allow";
  	}
  }

if(empty($_POST['email'])){
	$email_error = "emailcannot be empty";
}else{
	$email = test_input($_POST["email"]);
	$email = test_email_input($_POST["email"]);
	if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
		$email_error = " a valid Eamil requre";
	}
}

 if(empty($_POST["phone"])){
   $phone_error = "phone number require";

 }else{
 	$phone = test_input($_POST["phone"]);
 	$phone = filter_var($phone , FILTER_SANITIZE_NUMBER_INT);
 	if(preg_match("/^[0-9]{12}+$/", $phone)){ $phone_error = "invalid phone number";}
 }

 if (empty($_POST["country"])){
 	$country_error = "country cannot be empty";
 }else{
 	$country = test_input($_POST["country"]);
 	if(!ctype_alpha($country)){$country_error = "only letter and white spaces allow";}
 }

	$file_name =$_FILES["img1"]["name"];
	$file_size =$_FILES["img1"]["size"];
	$file_temp_name = $_FILES["img1"]["tmp_name"];
	$destination = "images/".$file_name;
	if(move_uploaded_file($file_temp_name, $destination)== true){
		$fname = $sname = $email = $phone = $country = $file_error = $success = "";
		$success = "thank you uploaded successfully";
	}else{ $file_error = "please upload file";}

 }


 function test_input($data){
 	$data = trim($data);
 	$data = stripcslashes($data);
 	$data = htmlspecialchars($data);
 	return $data;
 }

 function test_email_input($valid){
   $valid = filter_var($valid, FILTER_SANITIZE_EMAIL);
   return $valid;
 }

?>